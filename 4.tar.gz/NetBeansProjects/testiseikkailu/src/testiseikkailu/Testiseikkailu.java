/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testiseikkailu;
import java.util.Scanner;
/**
 *
 * @author guest-lri63p
 */
public class Testiseikkailu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        {
            Scanner lukija = new Scanner(System.in);
            while(true) {
                System.out.println("Anna salasana.");
                String sana = lukija.nextLine();
                if (sana.equals("qwerty")) {
                       break;
                }
            }
            System.out.println ("Valmis!");
            }
        }
    }

        

    

