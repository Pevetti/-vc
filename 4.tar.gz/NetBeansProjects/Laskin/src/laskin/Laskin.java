/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laskin;

import java.util.Scanner;

/**
 *
 * @author guest-lri63p
 */
public class Laskin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
        while(true) {
            
            System.out.println("Kuinka pitkiä listoja haluat käsitellä???");
            String sana = lukija.nextLine();
            if (!sana.equals("0")) {  
                break;
            }
        }
    }

}
