package laskin;

import java.util.Scanner;


public class Laskin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
        while(true) {
            
            System.out.println("Kuinka pitkiä listoja haluat käsitellä???");
            String sana = lukija.nextLine();
            int luku = Integer.parseInt(sana);
            if (0 < luku) 
                break;
            for (int i = 0; i < 10; i++) {
                
                }
            }
    }
}


    
